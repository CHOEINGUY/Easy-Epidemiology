# 유행곡선 증상 발현 시간 간격 분할 로직 분석

## 개요
EpidemicCurve.vue 컴포넌트에서 환자들의 증상 발현 시간을 설정된 시간 간격(3, 6, 12, 24, 48시간)으로 자동 분할하여 유행곡선을 생성하는 로직에 대한 상세 분석입니다.

## 핵심 함수들

### 1. `patientOnsetTimes` - 환자 증상 발현 시간 수집
```javascript
const patientOnsetTimes = computed(() => {
  if (!rows.value || rows.value.length === 0) return [];
  return rows.value
    .filter((r) => r.isPatient === "1" && r.symptomOnset)  // 환자이면서 증상발현시간이 있는 경우만
    .map((r) => {
      try {
        const dateStr = r.symptomOnset.includes("T")
          ? r.symptomOnset
          : r.symptomOnset.replace(" ", "T");
        const d = new Date(dateStr);
        return !isNaN(d.getTime()) ? d : null;
      } catch {
        return null;
      }
    })
    .filter((d) => d)
    .sort((a, b) => a.getTime() - b.getTime());  // 시간순 정렬
});
```

**역할**: 
- 환자 데이터에서 유효한 증상 발현 시간만 추출
- Date 객체로 변환하여 시간순 정렬
- 잘못된 날짜 데이터는 필터링하여 제외

### 2. `floorToIntervalStart` - 시간 간격 시작점 계산
```javascript
const floorToIntervalStart = (timestamp, intervalHours) => {
  try {
    if (isNaN(timestamp) || isNaN(intervalHours) || intervalHours <= 0) {
      return NaN;
    }
    
    const date = new Date(timestamp);
    const localHours = date.getHours();
    const startHour = Math.floor(localHours / intervalHours) * intervalHours;
    const blockStartDate = new Date(
      date.getFullYear(),
      date.getMonth(),
      date.getDate(),
      startHour,
      0, 0, 0
    );
    
    return blockStartDate.getTime();
  } catch (error) {
    return NaN;
  }
};
```

**역할**:
- 특정 시점을 주어진 시간 간격의 시작점으로 내림 처리
- 예: 14:30을 6시간 간격으로 처리하면 12:00:00으로 조정
- 분/초는 모두 0으로 초기화

### 3. `symptomOnsetTableData` - 메인 로직

#### 3-1. 초기 설정 및 검증
```javascript
const symptomOnsetTableData = computed(() => {
  const intervalHours = selectedSymptomInterval.value;  // 사용자 선택 간격 (3,6,12,24,48)
  
  // 데이터 유효성 검증
  if (!intervalHours || !patientOnsetTimes.value || patientOnsetTimes.value.length === 0 ||
      !firstOnsetTime.value || !lastOnsetTime.value) {
    return [];
  }

  const intervalMillis = intervalHours * 3600000;  // 시간을 밀리초로 변환
  const minTimestamp = firstOnsetTime.value.getTime();  // 첫 환자 시간
  const maxTimestamp = lastOnsetTime.value.getTime();   // 마지막 환자 시간
```

#### 3-2. 시작 구간 계산
```javascript
  // 첫 번째 구간 시작점 계산
  const blockStartTimestamp = floorToIntervalStart(minTimestamp, intervalHours);
  
  // 첫 환자가 포함되도록 구간 시작점 조정
  let firstIntervalStart = blockStartTimestamp;
  while (firstIntervalStart > minTimestamp) {
      firstIntervalStart -= intervalMillis;  // 필요시 구간을 앞으로 이동
  }
  
  // 첫 환자가 실제로 구간에 포함되는지 확인
  if (minTimestamp >= firstIntervalStart + intervalMillis) {
      firstIntervalStart += intervalMillis;
  }
```

#### 3-3. 구간별 환자 수 계산
```javascript
  const data = [];
  let currentIntervalStart = firstIntervalStart;
  let guard = 0; // 무한루프 방지

  while (currentIntervalStart <= maxTimestamp && guard < 1000) {
    const currentIntervalEnd = currentIntervalStart + intervalMillis;
    
    // 현재 구간에 속하는 환자 수 계산
    let count = 0;
    for (const time of patientOnsetTimes.value) {
      const timestamp = time.getTime();
      if (timestamp >= currentIntervalStart && timestamp < currentIntervalEnd) {
        count++;
      }
    }

    // 환자가 있거나 컨텍스트상 필요한 구간만 추가
    if (count > 0 || data.length === 0 || currentIntervalStart <= maxTimestamp) {
      data.push({
        intervalLabel: `${formatDateTime(new Date(currentIntervalStart))} ~ ${formatDateTime(new Date(currentIntervalEnd))}`,
        count,
      });
    }

    currentIntervalStart = currentIntervalEnd;
    guard++;
  }
```

## 시간 간격 분할 기본 원리

### 🕐 **0시 기준 고정 구간 시스템**

**네, 맞습니다!** 기본적으로 모든 시간 간격은 **0시(자정)부터 시작하는 고정 구간**으로 나뉩니다.

#### 각 간격별 고정 구간:
```
3시간 간격:  00-03 | 03-06 | 06-09 | 09-12 | 12-15 | 15-18 | 18-21 | 21-24
6시간 간격:  00-06 | 06-12 | 12-18 | 18-24
12시간 간격: 00-12 | 12-24  
24시간 간격: 00-24
```

### 📊 **floorToIntervalStart 함수 동작**

```javascript
// 예시: 14:30을 6시간 간격으로 처리
const localHours = 14;  // 14시
const startHour = Math.floor(14 / 6) * 6;  // Math.floor(2.33) * 6 = 12
// 결과: 12:00:00
```

**계산 과정:**
1. 현재 시간(14시)을 간격(6시간)으로 나눔: 14 ÷ 6 = 2.33...
2. 소수점 버림: Math.floor(2.33) = 2
3. 간격 크기를 곱함: 2 × 6 = 12
4. 결과: 12시 구간에 속함

## 시간 간격 분할 예시

### 예시 데이터
- 환자 A: 2024-04-08 14:30 증상 발현
- 환자 B: 2024-04-08 16:15 증상 발현  
- 환자 C: 2024-04-08 18:45 증상 발현
- 선택된 간격: 6시간

### 처리 과정

1. **시간 정렬**: 14:30 → 16:15 → 18:45

2. **고정 구간 확인**:
   ```
   6시간 간격 고정 구간:
   00:00~06:00 | 06:00~12:00 | 12:00~18:00 | 18:00~24:00
   ```

3. **각 환자의 구간 배정**:
   - 환자 A (14:30): `Math.floor(14/6)*6 = 12` → 12:00~18:00 구간
   - 환자 B (16:15): `Math.floor(16/6)*6 = 12` → 12:00~18:00 구간  
   - 환자 C (18:45): `Math.floor(18/6)*6 = 18` → 18:00~24:00 구간

4. **구간별 집계**:
   - 12:00~18:00: 환자 A(14:30), 환자 B(16:15) → **2명**
   - 18:00~24:00: 환자 C(18:45) → **1명**

5. **결과 테이블**:
   ```
   시간 구간          | 환자 수
   12:00 ~ 18:00     | 2
   18:00 ~ 24:00     | 1
   ```

### 🎯 **핵심 포인트**

1. **고정 구간**: 데이터와 관계없이 0시부터 시작하는 고정된 구간 사용
2. **자동 배정**: 각 환자의 시간이 어느 구간에 속하는지 자동 계산
3. **막대 높이**: 각 구간에 속한 환자 수가 차트의 막대 높이가 됨

따라서 **"0시부터 시작해서 고정 구간으로 나누고, 해당 구간에 맞는 막대에 환자 수를 표현한다"**는 이해가 정확합니다! 🎯

## 시간 간격별 특징

### 3시간 간격
- **장점**: 세밀한 시간대 분석 가능
- **단점**: 구간이 많아져 차트가 복잡해질 수 있음
- **적합**: 짧은 기간의 급성 발생 분석

### 6시간 간격  
- **장점**: 하루를 4구간으로 나누어 일상 패턴 파악
- **적합**: 일반적인 유행곡선 분석

### 12시간 간격
- **장점**: 오전/오후 패턴 분석
- **적합**: 중간 규모 발생 분석

### 24시간 간격
- **장점**: 일별 발생 패턴 분석
- **적합**: 장기간 발생 추이 분석

### 48시간 간격
- **장점**: 전체적인 발생 추이 파악
- **적합**: 매우 장기간 또는 산발적 발생 분석

## 현재 로직의 특징

### 장점
1. **자동 구간 조정**: 첫 환자가 반드시 포함되도록 시작점 자동 조정
2. **유연한 간격**: 5가지 시간 간격 선택 가능
3. **성능 최적화**: filter 대신 for 루프 사용으로 성능 향상
4. **안전성**: 무한루프 방지 가드 및 에러 처리

### 제한사항
1. **고정 간격**: 사용자 정의 간격 불가
2. **시간 경계**: 자정을 기준으로 한 경계 처리
3. **빈 구간**: 환자가 없는 중간 구간도 표시될 수 있음

## 🚨 **현재 로직의 중요한 문제점**

### **양쪽 0명 구간 누락 이슈**

**표준 유행곡선**에서는 발생 패턴의 완전한 형태를 보여주기 위해 **양쪽에 0명인 구간들이 필수적으로 표시**되어야 합니다.

#### 현재 상황 (문제):
```
환자 발생: 12-18시(2명), 18-24시(1명)

현재 차트: [12-18시: 2명] [18-24시: 1명]
            ↑ 갑자기 시작     ↑ 갑자기 끝
```

#### 표준 유행곡선 (올바른 방식):
```
표준 차트: [06-12시: 0명] [12-18시: 2명] [18-24시: 1명] [00-06시: 0명]
           ↑ 발생 전 기간    ↑ 발생기간      ↑ 발생기간     ↑ 발생 후 기간
```

### **왜 양쪽 0명 구간이 중요한가?**

1. **유행의 시작과 종료 명확화**: 언제 시작되고 언제 끝났는지 시각적으로 명확
2. **패턴 인식**: 급격한 상승/하강 vs 점진적 변화 구분 가능
3. **역학적 해석**: 노출 이전 기간과 발생 종료 시점 파악
4. **표준 준수**: 역학 분야의 표준적인 유행곡선 표현 방식

### **현재 코드의 문제 부분**

```javascript
// 현재 로직: 첫 환자부터 마지막 환자까지만 표시
let firstIntervalStart = blockStartTimestamp;
while (currentIntervalStart <= maxTimestamp && guard < 1000) {
  // 환자가 있는 구간만 처리...
}
```

**✅ 수정 완료**: 
- 첫 환자 이전 1개 구간 추가
- 마지막 환자 이후 1개 구간 추가

### **해결 과정 및 최종 로직**

#### **1단계: 기본 패딩 로직 구현**
```javascript
// 🔥 NEW: 양쪽 패딩 구간 설정 (앞뒤로 1개씩)
const PADDING_INTERVALS_BEFORE = 1;
const PADDING_INTERVALS_AFTER = 1;

// 마지막 환자 이후 1개 구간을 추가하여 종료점 확장
const extendedMaxTimestamp = maxTimestamp + (PADDING_INTERVALS_AFTER * intervalMillis);
```

#### **2단계: 앞쪽 패딩 문제 해결**
**문제**: while 루프가 패딩을 무효화
```javascript
// ❌ 잘못된 로직
let firstIntervalStart = blockStart - padding;
while (firstIntervalStart > minTimestamp) {  // 패딩 제거!
    firstIntervalStart -= intervalMillis;
}
```

**해결**: 단계별 처리
```javascript
// ✅ 올바른 로직
// 1단계: 첫 환자가 속한 구간 찾기
let firstPatientIntervalStart = blockStartTimestamp;
while (firstPatientIntervalStart > minTimestamp) {
    firstPatientIntervalStart -= intervalMillis;
}
if (minTimestamp >= firstPatientIntervalStart + intervalMillis) {
    firstPatientIntervalStart += intervalMillis;
}

// 2단계: 그 구간 이전에 패딩 추가
let firstIntervalStart = firstPatientIntervalStart - (PADDING_INTERVALS_BEFORE * intervalMillis);
```

#### **3단계: 뒤쪽 패딩 문제 해결**
**문제**: 차트 생성 시 마지막 구간 제거
```javascript
// ❌ 차트에서 패딩 구간 제거
const validData = data.slice(0, -1);
```

**해결**: 모든 구간 사용
```javascript
// ✅ 패딩 구간 포함 모든 데이터 사용
const validData = data;
```

#### **4단계: 최종 완성된 로직**
```javascript
// 양쪽 패딩 구간 설정
const PADDING_INTERVALS_BEFORE = 1;
const PADDING_INTERVALS_AFTER = 1;

// 첫 환자 구간 찾기 → 패딩 추가
let firstPatientIntervalStart = blockStartTimestamp;
while (firstPatientIntervalStart > minTimestamp) {
    firstPatientIntervalStart -= intervalMillis;
}
let firstIntervalStart = firstPatientIntervalStart - (PADDING_INTERVALS_BEFORE * intervalMillis);

// 확장된 종료점 설정
const extendedMaxTimestamp = maxTimestamp + (PADDING_INTERVALS_AFTER * intervalMillis);

// 모든 구간 처리 (0명 구간 포함)
while (currentIntervalStart <= extendedMaxTimestamp && guard < 1000) {
  // 환자 수 계산 후 모든 구간 추가
  data.push({ intervalLabel, count });
}

// 차트에서도 모든 데이터 사용
const validData = data; // slice 제거
```

### **결과 비교**

#### **수정 전 (문제 상황):**
```
테이블: 12-18시(2명) → 18-24시(1명)
차트:   [막대2] [막대1]
        ↗️갑자기시작  ↘️갑자기끝
```

#### **수정 후 (표준 유행곡선):**
```
테이블: 18-24시(0명) → 0-6시(4명) → ... → 12-18시(1명) → 18-24시(0명)
차트:   [   0   ] [막대4] [막대3] [막대7] [막대3] [막대4] [막대2] [막대1] [   0   ]
        ↗️발생전    ↗️발생시작 ──── 발생중 ──── ↘️발생감소 ↘️발생후
```

### **✨ 완성된 표준 유행곡선의 특징**

1. **명확한 시작점**: 발생 이전 0명 구간으로 배경 제공
2. **명확한 종료점**: 발생 이후 0명 구간으로 완전한 패턴 표현
3. **패턴 인식**: 급격한 상승/하강 vs 점진적 변화 구분 가능
4. **역학적 해석**: 유행의 전체 생명주기 시각화

## 🎯 **프로젝트 완료 상태**

### **✅ 완료된 개선사항**
1. **양쪽 0명 구간 표시**: 발생 전후 구간을 포함한 완전한 유행곡선 표현
   - 앞쪽 패딩: 첫 환자 이전 1개 구간 추가
   - 뒤쪽 패딩: 마지막 환자 이후 1개 구간 추가
   - 표준 역학 차트 형태 완성

### **🔧 해결된 기술적 문제들**
1. **패딩 무효화 이슈**: while 루프에 의한 앞쪽 패딩 제거 문제 해결
2. **차트 슬라이스 이슈**: `data.slice(0, -1)`에 의한 뒤쪽 패딩 제거 문제 해결
3. **구간 계산 정확성**: 환자가 속한 구간을 정확히 찾아 패딩하는 로직 완성

## 🚀 **향후 개선 가능한 영역**

1. **동적 패딩 설정**: 앞뒤 패딩 구간 수를 사용자가 설정 가능하도록
2. **사용자 정의 간격**: 임의의 시간 간격 설정 기능 (현재: 3,6,12,24,48시간 고정)
3. **스마트 구간**: 데이터 분포에 따른 자동 최적 간격 제안
4. **시간대 처리**: 타임존 고려한 시간 처리
5. **빈 구간 옵션**: 빈 구간 표시/숨김 토글 기능
6. **구간 라벨링**: 더 직관적인 시간 구간 표시 방식
7. **패딩 비율**: 전체 발생 기간에 비례한 동적 패딩

## 📊 **현재 달성된 표준 유행곡선**

```
완벽한 유행곡선 형태:
[0명 패딩] → [발생 시작] → [발생 정점] → [발생 감소] → [0명 패딩]

역학적 해석 가능:
- 명확한 유행 시작/종료 시점
- 발생 패턴의 완전한 시각화
- 급격한 변화 vs 점진적 변화 구분
- 표준 역학 분석 도구로 활용 가능
``` 