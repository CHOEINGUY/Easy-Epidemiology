<template>
  <h1 class="m-0 text-2xl font-light font-['Noto_Sans_KR'] text-slate-800">
    Easy-Epidemiology Web v2.0
  </h1>
</template>

<script setup>
// No props needed for now as the text is static across the app
</script>
