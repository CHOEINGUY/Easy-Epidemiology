<template>
  <div class="w-full flex justify-between items-center px-5 py-4 border-b border-slate-100">
    <div class="flex gap-5">
      <div class="flex items-center gap-2.5">
        <label class="font-semibold text-slate-700 text-sm">폰트 크기:</label>
        <div class="relative inline-block">
          <button 
            class="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded text-slate-600 text-sm hover:bg-slate-100 hover:border-slate-300 transition-colors min-w-[60px]" 
            @click="cycleFontSize"
            @mouseenter="handleFontSizeMouseEnter"
            @mouseleave="handleFontSizeMouseLeave"
          >
            {{ fontSizeButtonText }}
          </button>
          
          <!-- Tooltip -->
          <Transition
            enter-active-class="transition duration-200 ease-out"
            enter-from-class="opacity-0 -translate-y-1"
            enter-to-class="opacity-100 translate-y-0"
            leave-active-class="transition duration-150 ease-in"
            leave-from-class="opacity-100 translate-y-0"
            leave-to-class="opacity-0 -translate-y-1"
          >
            <div v-if="activeTooltip === 'fontSize'" class="absolute top-full left-1/2 -translate-x-1/2 mt-2 px-3 py-2 bg-slate-800 text-white text-xs rounded shadow-lg whitespace-nowrap z-50 font-sans">
              {{ tooltipText }}
              <!-- Arrow -->
              <div class="absolute bottom-full left-1/2 -translate-x-1/2 border-[5px] border-transparent border-b-slate-800"></div>
            </div>
          </Transition>
        </div>
      </div>
    </div>
    <div class="text-sm font-medium text-slate-500">
      <p class="m-0">총 {{ rowCount }}명의 데이터 분석</p>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, defineProps, defineEmits } from 'vue';

const props = defineProps({
  fontSize: {
    type: Number,
    required: true
  },
  rowCount: {
    type: Number,
    required: true
  }
});

const emit = defineEmits(['update:fontSize']);

const fontSizes = [12, 14, 16];
const fontSizeLabels = ['작게', '보통', '크게'];

const fontSizeButtonText = computed(() => {
  const currentIndex = fontSizes.indexOf(props.fontSize);
  return currentIndex !== -1 ? fontSizeLabels[currentIndex] : '보통';
});

// Tooltip Management
const activeTooltip = ref(null);
const tooltipText = ref('');

const showTooltip = (key, text) => {
  activeTooltip.value = key;
  tooltipText.value = text;
};

const hideTooltip = () => {
  activeTooltip.value = null;
};

const handleFontSizeMouseEnter = () => {
  const currentIndex = fontSizes.indexOf(props.fontSize);
  const nextIndex = (currentIndex + 1) % fontSizes.length;
  const nextFontSize = fontSizeLabels[nextIndex];
  showTooltip('fontSize', `폰트 크기를 ${nextFontSize}로 변경합니다`);
};

const handleFontSizeMouseLeave = hideTooltip;

const cycleFontSize = () => {
  const currentIndex = fontSizes.indexOf(props.fontSize);
  const nextIndex = (currentIndex + 1) % fontSizes.length;
  emit('update:fontSize', fontSizes[nextIndex]);
};
</script>
