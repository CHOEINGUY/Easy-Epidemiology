<template>
  <div class="flex items-center gap-3 py-2">
    <div class="p-2 bg-blue-100 text-blue-600 rounded-lg shadow-sm">
      <span class="material-icons text-2xl">people</span>
    </div>
    <h2 class="text-xl font-bold text-slate-800 tracking-tight">대상자 특성 분포</h2>
  </div>
</template>

<script setup>
// SummaryBar.vue - 상단 요약 바 컴포넌트
</script>
