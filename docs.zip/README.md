# Easy-Epidemiology Web v2.0 (간편 역학조사 시스템)

## 📌 소개 (Introduction)

**Easy-Epidemiology Web**은 감염병 역학조사를 지원하기 위한 통합 웹 애플리케이션입니다.
데이터 입력부터 통계 분석, 결과 시각화, 보고서 작성까지 역학조사관이 필요한 모든 기능을 하나의 플랫폼에서 제공합니다.

> **포트폴리오용 참고사항**:
> 이 프로젝트는 실제 역학조사 업무의 흐름(Workflow)을 심층적으로 분석하여, 사용자 경험(UX)을 극대화하고 반복적인 데이터 처리 작업을 자동화하는 데 초점을 맞추었습니다.

## ✨ 주요 기능 (Key Features)

- **📊 실시간 데이터 시각화**: 환자 특성, 유행 곡선(Epidemic Curve) 등을 인터랙티브 차트(ECharts)로 즉시 확인.
- **📉 자동 통계 분석**: 환자-대조군 연구, 코호트 연구, 사례군 조사 등 다양한 역학 연구 설계를 자동으로 분석하고 오즈비(OR), 상대위험비(RR), P-value를 산출.
- **📝 가상 스크롤 데이터 입력**: 수천 건의 대용량 데이터도 끊김 없이 입력 및 수정 가능한 가상 스크롤(Virtual Scroll) 기반 그리드 시스템.
- **📑 보고서 자동 생성**: 분석된 차트와 표를 드래그 앤 드롭으로 배치하여 HWP/PDF 보고서 초안을 자동으로 생성.
- **🔒 보안**: 관리자 승인 기반의 사용자 접근 제어 및 역할 관리.

## 🛠 기술 스택 (Tech Stack)

### Frontend

- **Framework**: Vue.js 3 (Composition API)
- **State Management**: Pinia
- **Routing**: Vue Router (Lazy Loading 적용)
- **Styling**: Tailwind CSS, SCSS (Modules)
- **Visualization**: Apache ECharts, Chart.js

### Tools & Libraries

- **Data Processing**: Lodash, Papaparse (CSV), SheetJS (Excel)
- **Virtual Control**: vue-virtual-scroller
- **Linting/Formatting**: ESLint, Prettier

## 🚀 설치 및 실행 (Setup & Run)

### 1. 요구사항 (Prerequisites)

- Node.js (v16 이상 권장)
- npm 또는 yarn

### 2. 설치 (Installation)

```bash
# 저장소 복제
git clone https://github.com/your-username/easy-epidemiology-web.git
cd easy-epidemiology-web

# 의존성 설치
npm install
```

### 3. 실행 (Development)

```bash
# 개발 서버 실행
npm run serve
```

### 4. 빌드 (Production Build)

```bash
npm run build
```

## 📂 프로젝트 구조 (Project Structure)

```
src/
├── components/          # 재사용 가능한 UI 컴포넌트
│   ├── Common/          # 공통 헤더 등 전역 컴포넌트
│   ├── EpidemicCurve/   # 유행곡선 분석 모듈
│   ├── CaseControl/     # 환자대조군 연구 모듈
│   └── ...
├── composables/         # Composition API 로직 (Hooks)
├── stores/              # Pinia 상태 관리 스토어
├── utils/               # 유틸리티 함수 (통계 계산, 날짜 처리 등)
└── router/              # 라우팅 설정 (Lazy Loading 적용됨)
```

## 🧪 테스트 및 품질 관리 (Quality Assurance)

- **Linting**: `npm run lint`를 통해 코드 스타일과 잠재적 오류를 검사합니다.
- **Refactoring**: 기능별 모듈화(Composable)와 공통 로직 추출을 통해 코드의 응집도를 높이고 결합도를 낮추었습니다.

---

© 2026 Easy-Epidemiology Project. All Rights Reserved.
